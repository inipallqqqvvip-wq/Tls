'use strict';

 // ────────────────────────
 // Cristial Avoid ─ config.js
 // ────────────────────────

const BOT_TOKEN = '8869017658:AAHxe-456cPybB07lFvv4dxNXTsmcVLzokY';
const OWNER_ID = '1485981151';
const ALLOWED_GROUPS = '-1004446312475';

 // ─────── OPSIONAL ─────── //
const FORCE_SUB_CHANNEL = '@lunar_foundd';
const FORCE_SUB_LINK = 'https://t.me/lunar_foundd';

module.exports = {
  tokenBot: BOT_TOKEN.trim(),
  ownerID: OWNER_ID.trim(),
  allowedGroups: ALLOWED_GROUPS.trim(),
  forceChannel: FORCE_SUB_CHANNEL.trim(),
  forceLink: FORCE_SUB_LINK.trim()
};